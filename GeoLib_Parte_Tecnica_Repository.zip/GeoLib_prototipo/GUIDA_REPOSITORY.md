# Come pubblicare il repository GeoLib su GitHub

1. Apri https://github.com e crea/accedi al tuo account.
2. Seleziona **New repository**, nome suggerito `geolib-project-work`, visibilità **Public**.
3. Scegli **Add file > Upload files** e carica il contenuto della cartella `GeoLib_prototipo`, mantenendo le sottocartelle `client`, `server`, `db`. Se l’interfaccia non mantiene le cartelle, usa Git da PC.
4. Controlla che nel repository compaiano `README.md`, `client/`, `server/`, `db/`, `docker-compose.yml`.
5. Copia l'indirizzo `https://github.com/TUO-ACCOUNT/geolib-project-work` e inseriscilo nel Project Work.
6. Il link GitHub è il **repository del codice**, distinto dall'eventuale sito Netlify.

**Non caricare** `node_modules`, file `.env` con password o chiavi, né dati personali reali. La cartella include `.gitignore` e il solo `.env.example`.

È un prototipo didattico: prima di renderlo pubblico come servizio usato da terzi servono protezioni privacy e sicurezza aggiuntive.
